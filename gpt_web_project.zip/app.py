
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = ""
    if request.method == "POST":
        prompt = request.form.get("prompt", "")
        content = request.form.get("content", "")
        result = f"Prompt: {prompt}\n\nContent:\n{content}"
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
